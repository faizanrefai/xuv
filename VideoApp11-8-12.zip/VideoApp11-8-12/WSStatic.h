//
//  WSStatic.h
//  VideoApp
//
//  Created by  on 13/07/12.
//  Copyright (c) 2012 . All rights reserved.
//



#define videoPlay  @"http://www.findyourzone.tv/webservice/userVideo.php"



#define allVideolist  @"http://www.findyourzone.tv/webservice/user_action.php"

